package com.example.weatherapp_01.Models

data class Rain(
    val `1h`: Double
)