package com.example.weatherapp_01.Models

data class Weather(
    val description: String,
    val icon: String,
    val id: Int,
    val main: String
)