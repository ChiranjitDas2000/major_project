package com.example.weatherapp_01.Models

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)